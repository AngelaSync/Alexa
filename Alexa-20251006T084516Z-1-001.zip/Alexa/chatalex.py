
import pywhatkit
import wikipedia
import pyjokes

def run_alexa():
    command = input("You: ").lower().strip()
    if not command.startswith("alexa"):
        print("Sorry, I don't understand your command.")
        return
    if "play" in command:
        song = command.replace("play", "").strip()
        print("Alexa: Playing"+song)
        pywhatkit.playonyt(song)
    elif "who is" in command:
        person = command.replace("who is", "").strip()
        try:
            info = wikipedia.summary(person, sentences=2)
            print("Alexa: "+info)
        except:
            print("Sorry, I couldn't find any information about"+person)
    else:
        print("Alexa: I beg your pardon?")

print("Alexa: Hi I am your chatbox assistant. Type commands starting with 'Alexa'")
while True:
    run_alexa()