import time
import tempfile
import os
import json
import requests
import speech_recognition as sr
import winsound
import webbrowser
import threading
import pyjokes
import pywhatkit
import wikipediaapi
import wikipedia
import win32com.client
import pythoncom
import keyboard  # Global hotkeys

# ---------------- CONFIG ----------------
VOICEVOX_URL = "http://127.0.0.1:50021"
SETTINGS_FILE = "chatbot_settings.json"
stop_tts_flag = False
sapi = win32com.client.Dispatch("SAPI.SpVoice")
tts_engine = "sapi"
sapi_voice_index = 0
voicevox_selected_style_id = None
voicevox_speakers = []
mode = "type"

try:
    from playsound import playsound
    _HAS_PLAYSOUND = True
except:
    _HAS_PLAYSOUND = False

# ---------------- Helpers ----------------
def play_file_interruptible(path):
    global stop_tts_flag
    stop_tts_flag = False

    def player():
        if _HAS_PLAYSOUND:
            playsound(path)
        else:
            os.startfile(path)
            while not stop_tts_flag:
                time.sleep(0.1)

    t = threading.Thread(target=player, daemon=True)
    t.start()

    def monitor_enter():
        global stop_tts_flag
        keyboard.wait("enter")
        stop_tts_flag = True

    threading.Thread(target=monitor_enter, daemon=True).start()
    return t

def safe_remove(path):
    try:
        os.remove(path)
    except:
        pass

# ---------------- Settings ----------------
def save_settings():
    data = {
        "tts_engine": tts_engine,
        "sapi_voice_index": sapi_voice_index,
        "voicevox_selected_style_id": voicevox_selected_style_id,
        "mode": mode,
    }
    try:
        with open(SETTINGS_FILE,"w") as f:
            json.dump(data,f)
    except:
        pass

def load_settings():
    global tts_engine, sapi_voice_index, voicevox_selected_style_id, mode
    try:
        with open(SETTINGS_FILE,"r") as f:
            data = json.load(f)
            tts_engine = data.get("tts_engine","sapi")
            sapi_voice_index = data.get("sapi_voice_index",0)
            voicevox_selected_style_id = data.get("voicevox_selected_style_id")
            mode = data.get("mode","type")
            if tts_engine=="sapi":
                set_sapi_voice(sapi_voice_index)
    except:
        pass

# ---------------- Microsoft ----------------
def list_sapi_voices():
    voices = sapi.GetVoices()
    print("\n--- Microsoft SAPI Voices ---")
    for i in range(voices.Count):
        v = voices.Item(i)
        print(f"{i+1}. {v.GetDescription()}")
    return voices

def set_sapi_voice(index):
    voices = sapi.GetVoices()
    if 0<=index<voices.Count:
        sapi.Voice = voices.Item(index)
        return True
    return False

def speak_sapi_interruptible(text):
    """SAPI TTS that starts immediately and is interruptible by ENTER."""
    global stop_tts_flag
    stop_tts_flag = False  # reset flag

    def tts_thread():
        try:
            pythoncom.CoInitialize()
            sp = win32com.client.Dispatch("SAPI.SpVoice")
            voices = sp.GetVoices()
            if 0 <= sapi_voice_index < voices.Count:
                sp.Voice = voices.Item(sapi_voice_index)

            chunks = [c.strip() for c in text.replace("\n", ". ").split(". ") if c.strip()]
            for chunk in chunks:
                if stop_tts_flag:
                    break
                sp.Speak(chunk)  # synchronous, blocking call
        except Exception as e:
            print("TTS error:", e)
        finally:
            pythoncom.CoUninitialize()

    t_thread = threading.Thread(target=tts_thread, daemon=True)
    t_thread.start()

    # Only start ENTER monitor AFTER TTS starts
    def monitor_enter():
        global stop_tts_flag
        while t_thread.is_alive():
            if keyboard.is_pressed("enter"):
                stop_tts_flag = True
                break
            time.sleep(0.05)

    threading.Thread(target=monitor_enter, daemon=True).start()


# ---------------- VoiceVox ----------------
def fetch_voicevox_speakers():
    try:
        r = requests.get(f"{VOICEVOX_URL}/speakers",timeout=15)
        r.raise_for_status()
        return r.json()
    except:
        print("Cannot fetch VoiceVox speakers.")
        return []

def show_voicevox_list(speakers):
    print("\nVoiceVox voices:")
    idx = 1
    seen = set()
    voice_list = []
    for spk in speakers:
        name = spk.get("name","")
        styles = spk.get("styles",[])
        if name and name not in seen and styles:
            style = styles[0]
            print(f"{idx}. {name} ({style.get('name','')}) ID:{style.get('id')}")
            voice_list.append(style.get("id"))
            seen.add(name)
            idx+=1
    return voice_list

def voicevox_synthesize_and_play_threaded(text, speaker_id=1):
    """VoiceVox playback with interrupt."""
    global stop_tts_flag
    stop_tts_flag = False

    def task():
        try:
            q = requests.post(f"{VOICEVOX_URL}/audio_query", params={"text":text,"speaker":speaker_id},timeout=20)
            q.raise_for_status()
            s = requests.post(f"{VOICEVOX_URL}/synthesis", params={"speaker":speaker_id}, json=q.json(),timeout=45)
            s.raise_for_status()
            with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp:
                tmp.write(s.content)
                tmp_path = tmp.name
            play_file_interruptible(tmp_path)
            while not stop_tts_flag and os.path.exists(tmp_path):
                time.sleep(0.05)
            safe_remove(tmp_path)
        except:
            print("VoiceVox error")

    threading.Thread(target=task, daemon=True).start()

# ---------------- Menus ----------------
def microsoft_menu():
    global sapi_voice_index, tts_engine
    tts_engine="sapi"
    list_sapi_voices()
    while True:
        choice = input("Enter number, \n'p <num>' preview, \n'q' cancel: ").strip().lower()
        if choice=="q": return
        if choice.startswith("p"):
            parts=choice.split()
            idx=int(parts[1])-1 if len(parts)>1 else int(input("Number: "))-1
            speak_sapi_interruptible("Hello! This is a preview of this voice.")
            continue
        try:
            idx=int(choice)-1
            if set_sapi_voice(idx):
                sapi_voice_index=idx
                print(f"Selected Microsoft voice #{idx+1}")
                return
        except:
            print("Invalid input")

def voicevox_menu():
    global voicevox_selected_style_id, tts_engine, voicevox_speakers
    tts_engine="voicevox"
    voicevox_speakers=fetch_voicevox_speakers()
    if not voicevox_speakers: return
    voice_list=show_voicevox_list(voicevox_speakers)
    while True:
        choice=input("Select [num], \npreview 'p <num]', \n refresh 'r', \ncancel 'q': ").strip().lower()
        if choice=="q": return
        if choice=="r":
            voicevox_speakers=fetch_voicevox_speakers()
            voice_list=show_voicevox_list(voicevox_speakers)
            continue
        if choice.startswith("p"):
            parts=choice.split()
            idx=int(parts[1]) if len(parts)>1 else int(input("Number: "))
            sid=voice_list[idx-1]
            voicevox_synthesize_and_play_threaded("Hello! This is a preview.", sid)
            continue
        try:
            idx=int(choice)
            if 1<=idx<=len(voice_list):
                voicevox_selected_style_id=voice_list[idx-1]
                print(f"Selected VoiceVox voice #{idx}")
                return
        except:
            print("Invalid input")

def change_voice_prompt():
    global tts_engine
    opt=input(f"Engine:{tts_engine}. Enter for menu, 'm' Microsoft, 'v' VoiceVox: ").strip().lower()
    if opt=="m": microsoft_menu()
    elif opt=="v": voicevox_menu()
    else: microsoft_menu() if tts_engine=="sapi" else voicevox_menu()

def show_help():
    print("""
Commands:
 switch to microsoft | switch to voicevox
 time | joke | who is / what is / define
 route to / directions / go to / navigate to
 change voice | preview voice
 mode voice/type
 help | exit / quit / bye
""")

# ---------------- Chat Logic ----------------
def open_google_maps_route(destination):
    try:
        url=f"https://www.google.com/maps/dir/?api=1&destination={destination.replace(' ','+')}"
        webbrowser.open(url)
        return f"Showing directions to {destination}"
    except:
        return "Cannot open Google Maps"

def get_wikipedia_summary(topic):
    topic = topic.strip()
    if not topic: return "What to search?"
    wikiapi = wikipediaapi.Wikipedia(language="en", user_agent="LexBot/1.0")
    page = wikiapi.page(topic)
    if page.exists():
        return page.summary[:500]
    search_results = wikipedia.search(topic)
    if search_results:
        best_match = search_results[0]
        try:
            return wikipedia.summary(best_match, sentences=2)
        except wikipedia.exceptions.DisambiguationError as e:
            options = ", ".join(e.options[:5])
            return f"Topic is ambiguous. Did you mean: {options}?"
        except wikipedia.exceptions.PageError:
            return f"No Wikipedia page found for '{topic}'"
    return f"No info found for '{topic}'"

def chatbot_response(user_text):
    txt=user_text.lower()
    if "joke" in txt: return pyjokes.get_joke()
    elif "time" in txt: return time.strftime("It's %I:%M %p")
    elif any(k in txt for k in ("go to","navigate to","directions to","route to")):
        for k in ("go to","navigate to","directions to","route to"):
            if k in txt:
                dest=txt.split(k,1)[1].strip()
                return open_google_maps_route(dest)
        return "Where to go?"
    elif any(k in txt for k in ("search","who is","what is","define")):
        topic = txt.replace("search","").replace("who is","").replace("what is","").replace("define","").strip()
        return get_wikipedia_summary(topic)
    elif txt.strip()=="": return ""
    elif txt in ("exit","quit","bye","stop"): return "Goodbye!"
    return f"You said: {user_text}"

# ---------------- Main ----------------
def listen_once():
    r = sr.Recognizer()
    try:
        with sr.Microphone() as source:
            print("🎤 Listening...")
            winsound.Beep(1000,150)
            audio = r.listen(source, timeout=5, phrase_time_limit=8)
            text = r.recognize_google(audio)
            print("You (voice):",text)
            return text
    except:
        return ""

def main():
    global tts_engine, mode, voicevox_selected_style_id
    print("=== Console Chatbot ===")
    load_settings()
    eng = input(f"Engine (microsoft/voicevox) [current:{tts_engine}]: ").strip().lower()
    if eng.startswith("v"): voicevox_menu()
    elif eng.startswith("m"): microsoft_menu()
    mode_choice = input(f"Mode voice/type [current:{mode}]: ").strip().lower()
    mode = "voice" if mode_choice.startswith("v") else "type"
    print("\nType 'help' for commands.\n")

    while True:
        user = listen_once() if mode=="voice" else input("You: ")
        if not user: continue
        cmd = user.strip().lower()
        if cmd in ("help","h"): show_help(); continue
        if cmd in ("exit","quit","bye"):
            print("Bot: Goodbye!")
            if tts_engine=="voicevox" and voicevox_selected_style_id:
                voicevox_synthesize_and_play_threaded("Goodbye!", voicevox_selected_style_id)
            else:
                speak_sapi_interruptible("Goodbye!")
            break
        if cmd.startswith("switch to microsoft"): microsoft_menu(); continue
        if cmd.startswith("switch to voicevox"): voicevox_menu(); continue
        if cmd.startswith("change voice"): change_voice_prompt(); continue
        if cmd.startswith("preview voice"):
            if tts_engine=="voicevox" and voicevox_selected_style_id:
                voicevox_synthesize_and_play_threaded("Hello! This is a preview.", voicevox_selected_style_id)
            else:
                speak_sapi_interruptible("Hello! This is a preview of the Microsoft voice.")
            continue
        if cmd.startswith("mode "):
            m = cmd.split(" ",1)[1]
            if m in ("voice","type"):
                mode = m
                print("Mode switched to",mode)
            else: print("Unknown mode")
            continue

        reply = chatbot_response(user)
        print("Bot:", reply)
        if tts_engine=="voicevox" and voicevox_selected_style_id:
            voicevox_synthesize_and_play_threaded(reply, voicevox_selected_style_id)
        else:
            speak_sapi_interruptible(reply)

        save_settings()

# ---------------- Run ----------------
if __name__ == "__main__":
    main()
